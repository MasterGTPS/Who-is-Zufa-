document.addEventListener("DOMContentLoaded", function () {
    console.log("Website Portofolio Zufarya siap digunakan!");
});
